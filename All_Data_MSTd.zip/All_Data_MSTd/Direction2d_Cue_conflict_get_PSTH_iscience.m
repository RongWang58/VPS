%%plot PSTH figures
load 'm7c305r1ch1.mat'%%example
load 'MSTd_cueconflict_ds.mat'
name=CueConflict2D_peak.name;
%% plot fig
FigureIndex=3;figure(FigureIndex);
set(FigureIndex,'Position', [5,50 1590,850], 'name', '2D cue_conflict');
orient landscape; axis off;
hold on;
axes('position',[0.05,0.9, 0.05,0.05] );
xlim( [0,100] );
ylim( [0,3] );
text(0, 5, name,'FontWeight','bold');
axis off;% Cell name
unique_azimuth_vis=CueConflict2D_peak.Conflict_2Dcue.unique_azimuth_vis;
unique_azimuth_moog=CueConflict2D_peak.Conflict_2Dcue.unique_azimuth_moog;
for ds=1:size(p_pref_type,2)
    if strcmp(name,p_pref_type(ds).name)==1
        clear P_vest,P_vest=p_pref_type(ds).P_vest;
        clear pref_vest_ds,pref_vest_ds=p_pref_type(ds).pref_vest_ds;
        clear P_vis,P_vis=p_pref_type(ds).P_vis;
        clear pref_vis_ds,pref_vis_ds=p_pref_type(ds).pref_vis_ds;
        clear cell_type_peak;cell_type_peak=p_pref_type(ds).type;
    end
end
if strcmp(cell_type_peak,'both')==1
    peakindex=CueConflict2D_peak.peakindex_vest;%for vps
    %     peakindex=CueConflict2D_peak.peakindex_vis;%for mstd
end
if strcmp(cell_type_peak,'vis only')==1
    peakindex=CueConflict2D_peak.peakindex_vis;
end
if strcmp(cell_type_peak,'vest only')==1
    peakindex=CueConflict2D_peak.peakindex_vest;
end
%%
disp('plot the PSTH');
maxvis_peak=max(CueConflict2D_peak.maxvis);
maxvest_peak=max(CueConflict2D_peak.maxvest);
max_count=ceil(max(maxvis_peak,maxvest_peak))+30; %setting y axis amp of psth
figure(FigureIndex);
% axes('position',[0.5 0.9 0.05 0.05]);
xoffset=-0.3;
yoffset=-0.25;
Step=25;x_time=[0:Step:2000];
unique_azimuth_moog=[-999;unique_azimuth_moog];%%add single conditions
unique_azimuth_vis=[-999;unique_azimuth_vis];
for i=1:length(unique_azimuth_moog)
    for j=1:length(unique_azimuth_vis)
        axes('position',[(0.04*i)+0.4+xoffset (0.045*j)+yoffset+0.5 0.03 0.03]);
        bar(x_time,[CueConflict2D_peak.Conflict_2Dcue.count_temp_400{i,j}]');hold on
        if i==1 & j~=1;
            plot([CueConflict2D_peak.peakindex_vis*Step,CueConflict2D_peak.peakindex_vis*Step],[0,500],'blue');
        elseif i~=1 & j==1;
            plot([CueConflict2D_peak.peakindex_vest*Step,CueConflict2D_peak.peakindex_vest*Step],[0,500],'red');
        else
            plot([peakindex*Step,peakindex*Step],[0,500],'green');
        end
        if i == 1
            if j == 1
                %set( gca,'xtick',[0 5],'xticklabel',{'0','2'});
                xlabel(['Moog: ' num2str(unique_azimuth_moog(i))]);
                ylabel(['Vis:' num2str(unique_azimuth_vis(j))]);
                set( gca,'xtick',[0 max(x_time)],'xticklabels',{'0','2'});
                set( gca,'ytick',[0 max_count]);
            else
                set( gca, 'xtick', [], 'ytick',[0 max_count]);
                ylabel([num2str(unique_azimuth_vis(j))]);
            end
        else
            if j==1
                xlabel([num2str(unique_azimuth_moog(i))]);
                set( gca,'xtick',[0 max(x_time)], 'xticklabels',{'0','2'});
                set( gca,'ytick', []);
            else
                set( gca, 'xtick', [],  'ytick', [] );
            end
        end
        % set the same scale for all plot
        xlim([0,max(x_time)]);
        ylim([0,max_count]);
        %axis off;
    end
end
